# Change Log

## July 8, 2016

* Implemented v1.1 features including: quick replies, message echoes, message reads, sending read receipts, sending typing indicators, sending gifs/videos/audio/files, adding metadata to sent messages, phone number button type

## May 11, 2016

* Initial launch of the sample app including all features launched at F8